from setuptools import setup

setup(name='self_balance',
      version='0.0.1',
      install_requires=['gym', 'pybullet']
)
